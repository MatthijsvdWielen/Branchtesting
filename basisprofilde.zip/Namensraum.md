### Namensraum

Canonical URL: **http://fhir.de/StructureDefinition/namingsystem-de-basis/0.2**

Alle in den deutschen Basisprofilen sowie hiervon abgeleiteten Profilen verwendeten Namensräume (NameSpace-Ressourcen) müssen dem nachfolgenden Profile entsprechen. Werden im Rahmen von hersteller- oder projektspezifischen Implementierungen Namensräume benötigt, gilt dies entsprechend.

Dieses Profil stellt sicher, dass für jeden Namensraum ein Typ festgelegt ist.

Auf diese Weise können gleichartige, aber unterschiedliche Namensräume gruppiert werden.
Dies ist beispielsweise bei Versichertennummern in der privaten Krankenversicherung sinnvoll.

{{tree:BasisprofilDE/namingsystem-de-basis-0.2}}

#### Beispiel

##### XML-Format

{{xml:BasisprofilDE/arge-ik-iknr}}

##### JSON-Format

{{json:BasisprofilDE/arge-ik-iknr}}