### Arzt-Fachgruppe der KBV

Verwendet unter anderem für die 8.+9. Stelle der LANR.

{{render:BasisprofilDE/s-bar2-arztnrfachgruppe}}