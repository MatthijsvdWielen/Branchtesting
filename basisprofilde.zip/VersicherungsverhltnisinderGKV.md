### Versicherungsverhältnis in der gesetzlichen Krankenversicherung (GKV)

Canonical URL: **http://fhir.de/StructureDefinition/coverage-de-gkv/0.2**

{{tree:BasisprofilDE/coverage-de-gkv-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/Example-coverage-de-gkv-1}}

##### JSON-Format

{{json:BasisprofilDE/Example-coverage-de-gkv-1}}
