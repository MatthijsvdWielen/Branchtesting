## Betriebsstätten-Hierarchie

Canonical URL: **http://fhir.de/StructureDefinition/betriebsstaetten-hierarchie/0.2**

{{tree:BasisprofilDE/betriebsstaetten-hierarchie-0.2}}
