### Hüftumfang

Canonical URL: **http://fhir.de/StructureDefinition/observation-de-hueftumfang/0.2**

{{tree:BasisprofilDE/observation-de-hueftumfang-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/observation-example-duplicate-3}}

##### JSON-Format

{{json:BasisprofilDE/observation-example-duplicate-3}}
