## Onlineprüfung eGK

Canonical URL: **http://fhir.de/StructureDefinition/gkv/onlinepruefung-egk/0.2**

{{tree:BasisprofilDE/gkv-onlinepruefung-egk-0.2}}
