### Patient im Versichertenstammdatenmanagement (VSDM)

Canonical URL: **http://fhir.de/StructureDefinition/patient-de-vsdm/0.2**

{{tree:BasisprofilDE/patient-de-vsdm-0.2}}
