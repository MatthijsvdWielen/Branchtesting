### Versicherungsverhältnis Selbstzahler

Canonical URL: **http://fhir.de/StructureDefinition/coverage-de-sel/0.2**

{{tree:BasisprofilDE/coverage-de-sel-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/coverage-example}}

##### JSON-Format

{{json:BasisprofilDE/coverage-example}}
