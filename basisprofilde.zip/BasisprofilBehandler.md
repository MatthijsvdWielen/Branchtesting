### Basisprofil Behandler

Canonical URL: **http://fhir.de/StructureDefinition/practitioner-de-basis/0.2**

{{tree:BasisprofilDE/practitioner-de-basis-0.2}}


#### Identifikation von Zahnärzten

Zur Identifikation von Zahnärzten dient die Zahnarztnummer (oder Zahnarzt-Abrechnungsnummer). Diese wird von den regionalen KZVen vergeben. Historisch bedingt existieren außerdem noch Zahnarztnummern, die von der KZBV vergeben wurden.
Hierfür sind insgesamt 18 NamingSystems nach dem Muster "http://fhir.de/NamingSystem/kzv/??/zahnarztnummer" vergeben. "??" entspricht hierbei der zweistelligen Ziffer aus der offziziellen Liste der KZVen.
Die gültigen NamingSystems finden sich in der [Übersicht der nationalen Namensräume](nationaleNamensrume).

Diese NamingSystems sind zur Vermeidung übermäßiger Komplexität nicht Bestandteil des Practitioner-Basisprofils.


#### Beispiele

##### XML-Format

Lebenslange Arztnummer (LANR):

{{xml:BasisprofilDE/Example-practitioner-de-basis-lanr}}

Zahnarztnummer:

{{xml:BasisprofilDE/Example-practitioner-de-basis-zahnarztnummer}}

##### JSON-Format

Lebenslange Arztnummer (LANR):

{{json:BasisprofilDE/Example-practitioner-de-basis-lanr}}

Zahnarztnummer:

{{json:BasisprofilDE/Example-practitioner-de-basis-zahnarztnummer}}
