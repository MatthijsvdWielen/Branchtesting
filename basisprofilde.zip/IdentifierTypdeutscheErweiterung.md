### Identifier-Typ (deutsche Erweiterung)

{{render:BasisprofilDE/identifier-type-de-basis-2}}