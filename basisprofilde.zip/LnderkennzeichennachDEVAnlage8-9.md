### ICD-10-GM

Enthält alle Versionen der Internationalen statistische Klassifikation der Krankheiten und verwandter Gesundheitsprobleme, 10. Revision, German Modification.

{{render:BasisprofilDE/icd-10-gm}}
