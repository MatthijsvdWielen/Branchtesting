## ICD-10-GM Stern-Code

Canonical URL: **http://fhir.de/StructureDefinition/icd-10-gm-stern/0.2**

{{tree:BasisprofilDE/icd-10-gm-stern-0.2}}
