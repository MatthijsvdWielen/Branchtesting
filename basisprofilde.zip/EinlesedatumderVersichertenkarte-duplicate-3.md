## Einlesedatum der Versichertenkarte

Canonical URL: **http://fhir.de/StructureDefinition/gkv/einlesedatum-karte/0.2**

{{tree:BasisprofilDE/gkv-einlesedatum-karte-0.2}}
