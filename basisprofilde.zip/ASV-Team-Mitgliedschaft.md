### ASV-Team-Mitgliedschaft

Canonical URL: **http://fhir.de/StructureDefinition/practitionerrole-de-asv-teamnummer/0.2**

{{tree:BasisprofilDE/practitionerrole-de-asv-teamnummer-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/practitionerrole-de-asv-team-example}}

##### JSON-Format

{{json:BasisprofilDE/practitionerrole-de-asv-team-example}}
