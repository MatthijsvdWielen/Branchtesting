### EBM

Einheitlicher Bewertungsmaßstab der vertragsärztlichen bzw. vertragspsychotherapeutischen Versorgung in Deutschland.

{{render:BasisprofilDE/ebm}}
