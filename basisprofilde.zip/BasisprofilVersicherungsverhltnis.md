### Basisprofil Versicherungsverhältnis

Canonical URL: **http://fhir.de/StructureDefinition/coverage-de-basis/0.2**

{{tree:BasisprofilDE/coverage-de-basis-0.2}}

