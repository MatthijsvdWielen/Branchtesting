### Basisprofil Diagnose

Canonical URL: **http://fhir.de/StructureDefinition/condition-de-basis/0.2**

{{tree:BasisprofilDE/condition-de-basis-0.2}}


#### Beispiele

##### XML-Format

Einfache Diagnose:

{{xml:BasisprofilDE/example-condition-de-basis-diagnose-1}}

Diagnose mit Seitenlokalisation:

{{xml:BasisprofilDE/example-condition-de-basis-diagnose-seitenlokalisation}}

Diagnose mit Angabe der Diagnosesicherheit:

{{xml:BasisprofilDE/example-condition-de-basis-diagnose-diagnosesicherheit}}

Diagnose mit Angabe der Seitenlokalisation und der Diagnosesicherheit:

{{xml:BasisprofilDE/example-condition-de-basis-diagnose-diagnosesicherheit-und-seite}}

##### JSON-Format

Einfache Diagnose:

{{json:BasisprofilDE/example-condition-de-basis-diagnose-1}}

Diagnose mit Seitenlokalisation:

{{json:BasisprofilDE/example-condition-de-basis-diagnose-seitenlokalisation}}

Diagnose mit Angabe der Diagnosesicherheit:

{{json:BasisprofilDE/example-condition-de-basis-diagnose-diagnosesicherheit}}

Diagnose mit Angabe der Seitenlokalisation und der Diagnosesicherheit:

{{json:BasisprofilDE/example-condition-de-basis-diagnose-diagnosesicherheit-und-seite}}
