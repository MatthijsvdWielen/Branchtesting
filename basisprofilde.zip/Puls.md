### Puls

Canonical URL: **http://fhir.de/StructureDefinition/observation-de-puls/0.2**

{{tree:BasisprofilDE/observation-de-puls-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/observation-example-duplicate-8}}

##### JSON-Format

{{json:BasisprofilDE/observation-example-duplicate-8}}
