## Zusatzinformationen für Rezepte

Canonical URL: **http://fhir.de/StructureDefinition/rezept-zusatzinfos/0.2**

{{tree:BasisprofilDE/rezept-zusatzinfos-0.2}}
