### EBM-Rechnungs-Element (ChargeItem)

Canonical URL: **http://fhir.de/StructureDefinition/chargeitem-ebm/0.2**

{{tree:BasisprofilDE/chargeitem-ebm-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/chargeitem-example}}

##### JSON-Format

{{json:BasisprofilDE/chargeitem-example}}
