## ICD-10-GM Diagnosesicherheit

Canonical URL: **http://fhir.de/StructureDefinition/icd-10-gm-diagnosesicherheit/0.2**

{{tree:BasisprofilDE/icd-10-gm-diagnosesicherheit-0.2}}
