### Bauchumfang

Canonical URL: **http://fhir.de/StructureDefinition/observation-de-bauchumfang/0.2**

{{tree:BasisprofilDE/observation-de-bauchumfang-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/observation-example}}

##### JSON-Format

{{json:BasisprofilDE/observation-example}}
