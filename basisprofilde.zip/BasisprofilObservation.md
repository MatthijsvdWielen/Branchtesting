### Basisprofil Observation

Canonical URL: **http://fhir.de/StructureDefinition/observation-de-basis/0.2**

{{tree:BasisprofilDE/observation-de-basis-0.2}}