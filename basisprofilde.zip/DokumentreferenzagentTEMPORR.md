## Dokumentreferenz: agent (TEMPORÄR)

Diese Extension stellt die Funktionalität von DocumentReference.agent (ab FHIR R4) für FHIR STU3 zur Verfügung.

Nach Portierung der deutschen Basisprofile auf FHIR R4 wird diese Extension somit obsolet.

Canonical URL: **http://fhir.de/StructureDefinition/temp/agent/0.2**

{{tree:BasisprofilDE/agent-0.2}}
