### Körpertemperatur

Canonical URL: **http://fhir.de/StructureDefinition/observation-de-koerpertemperatur/0.2**

{{tree:BasisprofilDE/observation-de-koerpertemperatur-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/observation-example-duplicate-6}}

##### JSON-Format

{{json:BasisprofilDE/observation-example-duplicate-6}}
