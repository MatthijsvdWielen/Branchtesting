# basisprofil-de
Basisprofil DE

Hier werden die (Zwischen-) Ergebnisse der Basisprofile von HL7 Deutschland veröffentlicht.

Die Profile werden von der Projektgruppe Basisprofilierung des Technischen Komitees FHIR von HL7 Deutschland e.V. erstellt.

Die Diskussion der Profile findet auf Zulip statt. Implementierer und Interessenten sind herzlich eingeladen, sich an der Diskussion zu beteiligen, Fragen zu stellen, oder Feedback zu geben.

Die derzeit veröffentlichten Profile und Resourcen sind experimentell!

Die neueste stabile Fassung findet sich unter http://ig.fhir.de/basisprofile-de/stable/

## Hinweis zur Versionierung

Einige Profile finden sich in mehreren Versionen in diesem Repository.

Es ist zu beachten, dass Profile, deren Status als **"retired"** gekennzeichnet sind, nicht mehr verwendet werden sollten. Diese befinden sich im Unterordner "retired".

Insbesondere sollten auch abgeleitete Profile spätestens mit Version 1.0 (geplante erste ballotierte, stabile Fassung) der deutschen Basisprofile angepasst werden und von diesem Versionsstand ableiten!
