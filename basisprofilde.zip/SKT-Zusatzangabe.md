## SKT-Zusatzangabe

Canonical URL: **http://fhir.de/StructureDefinition/kbv/skt-zusatzangabe/0.2**

{{tree:BasisprofilDE/kbv-skt-zusatzangabe-0.2}}
