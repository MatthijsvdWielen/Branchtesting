## ICD-10-GM Ausrufezeichen-Code

Canonical URL: **http://fhir.de/StructureDefinition/icd-10-gm-ausrufezeichen/0.2**

{{tree:BasisprofilDE/icd-10-gm-ausrufezeichen-0.2}}
