### Körpergröße

Canonical URL: **http://fhir.de/StructureDefinition/observation-de-koerpergroesse/0.2**

{{tree:BasisprofilDE/observation-de-koerpergroesse-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/observation-example-duplicate-5}}

##### JSON-Format

{{json:BasisprofilDE/observation-example-duplicate-5}}
