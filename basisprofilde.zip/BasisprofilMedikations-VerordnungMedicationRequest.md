### Basisprofil Medikations-Verordnung (MedicationRequest)

Canonical URL: **http://fhir.de/StructureDefinition/medicationrequest-de-basis/0.2**

{{tree:BasisprofilDE/medicationrequest-de-basis-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/medicationrequest-example}}

##### JSON-Format

{{json:BasisprofilDE/medicationrequest-example}}
