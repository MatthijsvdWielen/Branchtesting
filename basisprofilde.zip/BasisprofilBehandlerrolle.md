### Basisprofil Behandlerrolle

Canonical URL: **http://fhir.de/StructureDefinition/practitionerrole-de-basis/0.2**

{{tree:BasisprofilDE/practitionerrole-de-basis-0.2}}
