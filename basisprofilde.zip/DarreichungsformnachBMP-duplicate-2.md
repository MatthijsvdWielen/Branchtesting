### Darreichungsform nach BMP

{{render:BasisprofilDE/s-bmp-darreichungsform}}
