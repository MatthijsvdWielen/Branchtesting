## ICD-10-GM Haupt-Code bzw. Kreuz-Code

Canonical URL: **http://fhir.de/StructureDefinition/icd-10-gm-haupt-kreuz/0.2**

{{tree:BasisprofilDE/icd-10-gm-haupt-kreuz-0.2}}
