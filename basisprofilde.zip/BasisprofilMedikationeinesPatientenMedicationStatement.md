### Basisprofil Medikation eines Patienten (MedicationStatement)

Canonical URL: **http://fhir.de/StructureDefinition/medicationstatement-de-basis/0.2**

{{tree:BasisprofilDE/medicationstatement-de-basis-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/medicationstatement-example}}

##### JSON-Format

{{json:BasisprofilDE/medicationstatement-example}}
