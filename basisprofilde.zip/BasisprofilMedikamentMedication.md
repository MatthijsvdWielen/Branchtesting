### Basisprofil Medikament (Medication)

Canonical URL: **http://fhir.de/StructureDefinition/medication-de-basis/0.2**

{{tree:BasisprofilDE/medication-de-basis-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/medication-example}}

##### JSON-Format

{{json:BasisprofilDE/medication-example}}
