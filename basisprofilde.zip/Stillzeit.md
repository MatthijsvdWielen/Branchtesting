### Körpergewicht

Canonical URL: **http://fhir.de/StructureDefinition/observation-de-stillzeit/0.2**

{{tree:BasisprofilDE/observation-de-stillzeit-0.2-duplicate-2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/observation-example-duplicate-11}}

##### JSON-Format

{{json:BasisprofilDE/observation-example-duplicate-11}}
