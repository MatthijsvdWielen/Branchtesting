### Schwangerschaft

Canonical URL: **http://fhir.de/StructureDefinition/observation-de-schwangerschaft/0.2**

{{tree:BasisprofilDE/observation-de-schwangerschaft-0.2-duplicate-2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/observation-example-duplicate-10}}

##### JSON-Format

{{json:BasisprofilDE/observation-example-duplicate-10}}
