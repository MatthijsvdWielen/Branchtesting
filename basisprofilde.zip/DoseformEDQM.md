### Darreichungsform nach EDQM

{{render:BasisprofilDE/0.4.0.127.0.16.1.1.2.1}}