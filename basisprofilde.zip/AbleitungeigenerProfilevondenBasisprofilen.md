## Ableitung eigener Profile von den Basisprofilen

Die deutschen Basisprofile definieren Vorgaben, die deutschlandweit einheitlich umgesetzt werden sollten. Dies betrifft beispielsweise die Repräsentation von Identifikatoren (Versichertennummern, IK, BSNR, LANR usw.) sowie verbreiteter Terminologie-Systeme (ICD-10-GM, OPS, ...) und Datenelemente (VSDM/eGK, Darstellung von Personennamen und Adressen, typische Befunde, ...).

Hierdurch wird die Interoperabilität zwischen beliebigen Systemen, die konform zu den Basisprofilen sind, gewährleistet. Darüber hinaus besteht für Hersteller und Anwender der Vorteil, dass die hier definierten Elemente nicht erneut spezifiziert werden müssen, sondern aufgrund des Kommentierungs- und Abstimmungsverfahrens die jeweiligen Inhalte bereits sinnvoll abbilden.

Gleichzeitig stellen die Basisprofile den Rahmen zur Umsetzung eigener, anwendungsfallspezifischer Profile zur Verfügung. Sie sind offen gestaltet, so dass Anwender bzw. Hersteller für den konkreten Anwendungsfall bei Bedarf Einschränkungen und/oder Erweiterungen profilieren können.

Für diese Form der Ableitung existieren in FHIR definierte maschinenverarbeitbare Mechanismen. Es können beliebige Ableitungs-Hierarchien aufgebaut werden.

Die Profilierung eines abgeleiteten Profils erfolgt identisch mit der Profilierung einer Basis-Ressource. Lediglich die sogenannte baseDefinition ist eine andere.

**Beispiel (Auszug aus StructureDefinition-Ressourcen):**

* Profil leitet vom deutschen Patienten-Basisprofil ab:
~~~~
    <baseDefinition value="http://fhir.de/StructureDefinition/patient-de-basis/0.2" />
~~~~
* Profil leitet von der Basis-Ressource Patient ab:
~~~~
    <baseDefinition value="http://hl7.org/fhir/StructureDefinition/Patient" />
~~~~

Im verbreitet eingesetzten FHIR-Profil-Editor **[Forge](https://simplifier.net/forge/)** wird zur Ableitung von einem Profil der Menüpunkt **File -> New Derived Profile** verwendet. Anschließend kann das Profil, von dem abgeleitet werden soll, als Datei ausgewählt werden.