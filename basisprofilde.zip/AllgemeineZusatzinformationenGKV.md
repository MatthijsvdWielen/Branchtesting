## Allgemeine Zusatzinformationen VSDM

Canonical URL: **http://fhir.de/StructureDefinition/gkv/zusatzinfos-allgemein/0.2**

{{tree:BasisprofilDE/gkv-zusatzinfos-allgemein-0.2}}
