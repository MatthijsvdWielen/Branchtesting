# Grundlagen

## FHIR

Fast Healthcare Interoperable Resources (FHIR, ausgesprochen wie engl. “fire”) ist ein von HL7 erarbeiteter Standard. Er unterstützt den Datenaustausch zwischen Softwaresystemen im Gesundheitswesen.
FHIR beschreibt Datenformate und Elemente als sogenannte "Ressourcen" und bietet eine Schnittstelle (API) an, um diese auszutauschen. Die Vorteile der etablierten HL7-Standard-Produktlinien Version 2, Version 3 und CDA werden dabei mit jenen aktueller Web-Standards kombiniert. Ein starker Fokus liegt auf einer einfachen Implementierbarkeit.

Siehe: http://hl7.org/fhir

## Anwendung dieses Leitfadens

Dieser Leitfaden soll als Hilfestellung und Richtschnur vor und während der Entwicklung von Software oder abgeleiteten Profilen dienen.
Die enthaltenen Profile können aber auch für die Validierung bereits entwickelter Komponenten verwendet werden.

Um eine Instanz einer FHIR-Resource gegen eines der Deutschen Basisprofile zu validieren, gibt es mehrere mögliche Vorgehensweisen:

### Validierung von Ressourcen-Instanzen 
Für die Entwicklung standard-konformer Software ist die Validierung von Instanzen ein hilfreiches Werkzeug. 
Anleitungen zu verschiedenen Möglichkeiten, Ressourcen zu validieren befinden sich im [Wiki von HL7 Deutschland](http://wiki.hl7.de/index.php?title=Validierung_von_Instanzen#FHIR).


## Vorgehensweise

### Partizipation
Dieser Leitfaden wird vom Technischen Komitee für FHIR von HL7 Deutschland erstellt und gepflegt.
Die Diskussion dazu findet im [internationalen FHIR-Chat](http://chat.fhir.org "FHIR-Chat") im Stream "[german (d-a-ch)](https://chat.fhir.org/#narrow/stream/german.20(d-a-ch))" statt.
Weiterhin gibt es regelmäßige Treffen im Rahmen des [Interoperabilitätsforums](http://interoperabilitaetsforum.de/).
Die Teilnahme und Mitarbeit steht jedem offen. 
Weitere Hinweise zu den Mitwirkungsmöglichkeiten finden Sie [im Wiki von HL7 Deutschland](http://wiki.hl7.de/index.php?title=TC_FHIR#M.C3.B6glichkeiten_zur_Partizipation)

### Abstimmungsverfahren
Dieser Leitfaden wird in regelmäßigen Abständen zur Abstimmung und Kommentierung gestellt. 
Es gelten die von HL7 Deutschland e.V. festgelegten [Regeln](http://wiki.hl7.de/index.php?title=Abstimmungsverfahren_(Regeln)) für das Abstimmungsverfahren.


### Einreichung von Kommentaren
Kommentare können auch außerhalb eines Abstimmungsverfahrens entweder per Mail an tc@fhir.de eingereicht, oder direkt über den [Issue-Tracker](https://github.com/hl7germany/basisprofil-de/issues) erstellt werden.

### Auflösung von Kommentaren
Die Auflösung der Kommentare obliegt dem Technischen Komittee für FHIR bei HL7 Deutschland und folgt dem von diesem Komitee festgelegten [Verfahren](http://wiki.hl7.de/index.php?title=TC_FHIR#Aufl.C3.B6sung_von_Kommentaren).

### Weiterentwicklung dieses Leitfadens
Dieser Leitfaden erhebt keinen Anspruch auf Vollständigkeit.
Weitere Profile werden hinzugefügt, wenn sich aufgrund der aktuellen Aktivitäten der Deutschen Community der Bedarf für weitere Profile ergibt.
Vorschläge zur Erweiterung dieses Leitfadens können per Mail an [tc@fhir.de](mailto:tc@fhir.de) oder über den [Issue-Tracker](https://github.com/hl7germany/basisprofil-de/issues) eingereicht werden.


### Nomenklatur
Die im Rahmen dieses Leitfadens veröffentlichten Basis-Profile erhalten URLs der Form 
~~~~
http://fhir.de/<Ressourcen-Typ>/<Name des Profils>-de-basis
~~~~
UseCase-spezifische, von den Basis-Profilen abgeleitete Ressourcen erhalten eine URL der Form
~~~~
http://fhir.de/<Ressourcen-Typ>/<Name des Profils>-de-<Use-Case>
~~~~

Beispiel:
~~~~
http://fhir.de/StructureDefinition/patient-de-basis
http://fhir.de/StructureDefinition/patient-de-vsdm
~~~~

Die Schreibweise folgt dem Gebrauch im FHIR-Standard:
- Ressourcen-Typ: CamelCase
- Name: lowercase

Die canonical URLs dienen zwar nur der eindeutigen (Re-)Identifikation einer Ressource über Systemgrenzen hinweg, unabhängig von deren physikalischen Adresse, durch einen Redirect von http://fhir.de auf http://simplifier.org sind jedoch die technischen Voraussetzungen gegeben, um alle in diesem Leitfaden definierten URLs bei der Eingabe in einen Browser direkt zu der Spezifikation dieser Resource auf Simplifier aufzulösen. 

## Zertifizierung

Die Verwendung des Implementierungsleitfadens in Softwareprodukten ist grundsätzlich frei von jeglicher Zertifizierung.

## Stabilität der verwendeten Standards - Reifegrad

Der diesem Leitfaden zugrunde liegende FHIR-Standard hat derzeit den Status "Standard for Trial Use" und ist noch nicht normativ.
Dieser Leitfaden kann erst dann als normativ zur Abstimmung gebracht werden, wenn die darin profilierten Resourcen den normativen Status erreicht haben.

