### Einheiten für Körpergewicht

{{render:BasisprofilDE/einheiten-koerpergewicht}}