## Geschützte Zusatzinformationen VSDM

Canonical URL: **http://fhir.de/StructureDefinition/gkv/zusatzinfos-geschuetzt/0.2**

{{tree:BasisprofilDE/gkv-zusatzinfos-geschuetzt-0.2}}
