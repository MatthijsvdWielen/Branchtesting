### Basisprofil Patient

Canonical URL: **http://fhir.de/StructureDefinition/patient-de-basis/0.2**

{{structure:BasisprofilDE/patient-de-basis-0.2}}

#### Beispiele

##### XML-Format

Gesetzliche Krankenversichertennummer beim Patienten:

{{xml:BasisprofilDE/Example-patient-de-basis-kvid-10}}

Patient mit hausinternem Patienten-Identifikator (Medical Record Number):

{{xml:BasisprofilDE/patient-example}}

##### JSON-Format

Gesetzliche Krankenversichertennummer beim Patienten:

{{json:BasisprofilDE/Example-patient-de-basis-kvid-10}}

Patient mit hausinternem Patienten-Identifikator (Medical Record Number):

{{json:BasisprofilDE/patient-example}}
