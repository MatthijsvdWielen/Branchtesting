### Körpergewicht

Canonical URL: **http://fhir.de/StructureDefinition/observation-de-koerpergewicht/0.2**

{{tree:BasisprofilDE/observation-de-koerpergewicht-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/observation-example-duplicate-4}}

##### JSON-Format

{{json:BasisprofilDE/observation-example-duplicate-4}}
