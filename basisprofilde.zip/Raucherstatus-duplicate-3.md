### Raucherstatus

Canonical URL: **http://fhir.de/StructureDefinition/observation-de-raucherstatus/0.2**

{{tree:BasisprofilDE/observation-de-raucherstatus-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/observation-example-duplicate-9}}

##### JSON-Format

{{json:BasisprofilDE/observation-example-duplicate-9}}
