## Version der eGK

Canonical URL: **http://fhir.de/StructureDefinition/gkv/version-egk/0.2**

{{tree:BasisprofilDE/gkv-version-egk-0.2}}
