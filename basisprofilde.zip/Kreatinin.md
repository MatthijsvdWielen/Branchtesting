### Kreatinin

Canonical URL: **http://fhir.de/StructureDefinition/observation-de-kreatinin/0.2**

{{tree:BasisprofilDE/observation-de-kreatinin-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/observation-example-duplicate-7}}

##### JSON-Format

{{json:BasisprofilDE/observation-example-duplicate-7}}
