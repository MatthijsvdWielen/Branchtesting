### Basisprofil Organisation

Canonical URL: **http://fhir.de/StructureDefinition/organization-de-basis/0.2**

{{tree:BasisprofilDE/organization-de-basis-0.2}}


#### Beispiele

##### XML-Format

Beispiel einer Betriebsstätte

{{xml:BasisprofilDE/Organization-example-2}}

Beispiel eines ASV-Teams.

Hinweis: dies repräsentiert das ASV-Team als Organisationseinheit, nicht die ASV-Team-Mitgliedschaft eines Arztes.

{{xml:BasisprofilDE/Organization-asv-team-example}}

##### JSON-Format

Beispiel einer Betriebsstätte

{{json:BasisprofilDE/Organization-example-2}}

Beispiel eines ASV-Teams.

Hinweis: dies repräsentiert das ASV-Team als Organisationseinheit, nicht die ASV-Team-Mitgliedschaft eines Arztes.

{{json:BasisprofilDE/Organization-asv-team-example}}
