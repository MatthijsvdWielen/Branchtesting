### Basisprofil Allergie, Unverträglichkeit

Canonical URL: **http://fhir.de/StructureDefinition/allergyintolerance-de-basis/0.2**

{{tree:BasisprofilDE/allergyintolerance-de-basis-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/allergyintolerance-example}}

##### JSON-Format

{{json:BasisprofilDE/allergyintolerance-example}}
