## Freitext

Canonical URL: **http://fhir.de/StructureDefinition/freitext/0.2**

{{tree:BasisprofilDE/freitext-0.2}}
