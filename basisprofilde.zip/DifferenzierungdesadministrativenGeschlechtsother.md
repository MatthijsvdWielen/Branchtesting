## Differenzierung des administrativen Geschlechts 'other'

Canonical URL: **http://fhir.de/StructureDefinition/gender-amtlich-de/0.2**

{{tree:BasisprofilDE/gender-amtlich-de-0.2}}
