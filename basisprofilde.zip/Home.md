# Implementierungsleitfaden FHIR-Basis für das deutsche Gesundheitswesen

**vorgelegt von: HL7 Deutschland**

{{render:BasisprofilDE/HL7-DE-logo-120x120-png}}

---
Version: 0.2.30

Datum: 20.01.2020

Status: Fassung für das informative Abstimmungsverfahren zur Kommentierung (11-12/2018) mit Ergänzung der Geschlechts-Differenzierung divers/unbestimmt und der Versicherungsart "sonstige" sowie technischen Korrekturen.

Realm: Deutschland

frühere Fassungen: vgl. Versions-Historie

---

## Inhaltsverzeichnis
{{index:root}}

## Impressum

Dieser Leitfaden ist im Rahmen des Interoperabilitätsforums und den Technischen Komitees von HL7 Deutschland e. V. sowie der entsprechenden Projektgruppen zusammengestellt und unterliegt dem [Abstimmungsverfahren des Interoperabilitätsforums](http://wiki.hl7.de/index.php?title=Abstimmungsverfahren_(Regeln)) und der Technischen Komitees von [HL7 Deutschland e. V.](http://www.hl7.de).

## Ansprechpartner

* Simone Heckmann, Gefyra GmbH, DMI GmbH & Co. KG
* Stefan Lang, Lang Health IT Consulting
 
## Disclaimer

* Der Inhalt dieses Dokuments ist öffentlich. Zu beachten ist, dass Teile dieses Dokuments auf FHIR Version STU3 beruhen, für die Copyright HL7 International gilt.
* Obwohl diese Publikation mit größter Sorgfalt erstellt wurde, kann HL7 Deutschland keinerlei Haftung für direkten oder indirekten Schaden übernehmen, der durch den Inhalt dieser Spezifikation entstehen könnte.

## Autoren

* Simone Heckmann (SH), Gefyra GmbH, DMI GmbH & Co. KG
* Stefan Lang (SL), Lang Health IT Consulting
* Peter Scholz (PS), OSM AG
* Patrick Werner (PW), MOLIT Institut gGmbH

## Copyright-Hinweis, Nutzungshinweise

Copyright © 2016-2019: HL7 Deutschland e. V., Anna-Louisa-Karsch-Str. 2, 10178 Berlin

Der Inhalt dieser Spezifikation ist öffentlich. Die Nachnutzungs- bzw. Veröffentlichungsansprüche sind nicht beschränkt.

Zu den Nutzungsrechten der zugrunde liegenden FHIR-Technologie siehe die [FHIR-Basis-Spezifikation](https://www.hl7.org/fhir/).

Einige verwendete Codesysteme werden von anderen Organisationen herausgegeben und gepflegt. Es gilt das Copyright der dort jeweils aufgeführten Herausgeber (Publisher).

Die FHIR-Profile unterliegen neben dem Abstimmungsverfahren zusätzlich dem etablierten Kurationsverfahren des Technischen Komitees FHIR unter der Leitung von

* Simone Heckmann, Leiterin HL7 Technisches Komitee FHIR, DMI GmbH & Co. KG (Münster), Gefyra GmbH (Hürth)
* Stefan Lang, stellv. Leiter HL7 Technisches Komitee FHIR, Lang Health IT Consulting (Ehringshausen)

## Versions-Historie

* 0.2.30 (20.01.2020):  Ergänzung von <derivation value="constraint" /> in 3 Profilen (Diese Version wurde ursprünglich als 0.2.3 released, aufgrund von Semver-Inssues jedoch als 0.2.30 re-released).
* 0.2.2 (20.11.2019): Ergänzung des Wertes "sonstige Versicherungsart" im CodeSystem versicherungsart-de-basis. Technische Korrekturen (fehlerhafte Patterns durch Invarianten ersetzt).
* 0.2.1 (15.03.2019): Ergänzung der Extension "gender-amtlich-de" in den Patientenprofilen sowie der zugehörigen Terminologie-Ressourcen, ansonsten identisch mit Version 0.2
* 0.2 (16.11.2018): Entwurf für das 2. Kommentierungsverfahren
* 0.1 (15.09.2017): Entwurf für das 1. Kommentierungsverfahren<br>=> [Implementierungsleitfaden](https://github.com/hl7germany/Dokumente/blob/master/FHIR%20Leitfaden%20Basis%20DE%200.1.pdf)<br>=> [Conformance-Ressourcen](https://github.com/hl7germany/Dokumente/blob/master/basisprofil-de-0.1.zip)
