### Basisprofil Prozedur

Canonical URL: **http://fhir.de/StructureDefinition/procedure-de-basis/0.2**

{{tree:BasisprofilDE/procedure-de-basis-0.2}}


#### Beispiele

##### XML-Format

{{xml:BasisprofilDE/procedure-example}}

##### JSON-Format

{{json:BasisprofilDE/procedure-example}}
