## Ressourcen-Paket

Die in diesem Leitfaden beschriebenen Conformance- und Terminologie-Ressourcen stehen zur freien Verwendung zur Verfügung:

* ZIP-Archiv ([Download](http://ig.fhir.de/download/basisprofil.de-0.2.30.zip))
* NPM-Paket ([Installation via Paketmanager](https://simplifier.net/packages/basisprofil.de/0.2.30) oder [Download](http://ig.fhir.de/download/basisprofil.de-0.2.3.tgz))
