## Personenname

Canonical URL: **http://fhir.de/StructureDefinition/humanname-de-basis/0.2**

{{tree:BasisprofilDE/humanname-de-basis-0.2}}

### Beispiele

#### XML-Format

Geburtsname und früherer Name:
 
{{xml:BasisprofilDE/Example-patient-de-basis-humanname-1}}

Namenszusatz und Titel:

{{xml:BasisprofilDE/Example-patient-de-basis-humanname-namenszusatz-titel}}

Vorsatzwort:

{{xml:BasisprofilDE/Example-patient-de-basis-humanname-vorsatzwort}}

komplexer Name:

{{xml:BasisprofilDE/Example-patient-de-basis-humanname-komplex}}

#### JSON-Format

Geburtsname und früherer Name:
 
{{json:BasisprofilDE/Example-patient-de-basis-humanname-1}}

Namenszusatz und Titel:

{{json:BasisprofilDE/Example-patient-de-basis-humanname-namenszusatz-titel}}

Vorsatzwort:

{{json:BasisprofilDE/Example-patient-de-basis-humanname-vorsatzwort}}

komplexer Name:

{{json:BasisprofilDE/Example-patient-de-basis-humanname-komplex}}
