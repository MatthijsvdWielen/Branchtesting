## Adresse

Canonical URL: **http://fhir.de/StructureDefinition/address-de-basis/0.2**

{{tree:BasisprofilDE/address-de-basis-0.2}}

### Beispiele

#### XML-Format

Hier in der Verwendung als Patienten-Adresse:

{{xml:BasisprofilDE/Example-patient-de-basis-address-1}}

#### JSON-Format

Hier in der Verwendung als Patienten-Adresse:

{{json:BasisprofilDE/Example-patient-de-basis-address-1}}
