----
### Ambulanter/stationärer Fall / Kontakt (Encounter)

**Canonical**: ```http://fhir.de/CodeSystem/dkgev/Aufnahmeart```

{{render:http://fhir.de/CodeSystem/dkgev/Aufnahmeart}}

<br><br>

**Canonical**: ```http://fhir.de/CodeSystem/dgkev/Aufnahmeanlass```

{{render:http://fhir.de/CodeSystem/dgkev/Aufnahmeanlass}}

<br><br>

**Canonical**: ```http://fhir.de/CodeSystem/dkgev/AufnahmegrundErsteUndZweiteStelle```

{{render:http://fhir.de/CodeSystem/dkgev/AufnahmegrundErsteUndZweiteStelle}}

<br><br>

**Canonical**: ```http://fhir.de/CodeSystem/dkgev/AufnahmegrundDritteStelle```

{{render:http://fhir.de/CodeSystem/dkgev/AufnahmegrundDritteStelle}}

<br><br>

**Canonical**: ```http://fhir.de/CodeSystem/dkgev/AufnahmegrundVierteStelle```

{{render:http://fhir.de/CodeSystem/dkgev/AufnahmegrundVierteStelle}}

<br><br>

**Canonical**: ```http://fhir.de/CodeSystem/dkgev/EntlassungsgrundErsteUndZweiteStelle```

{{render:http://fhir.de/CodeSystem/dkgev/EntlassungsgrundErsteUndZweiteStelle}}

<br><br>

**Canonical**: ```http://fhir.de/CodeSystem/dkgev/EntlassungsgrundDritteStelle```

{{render:http://fhir.de/CodeSystem/dkgev/EntlassungsgrundDritteStelle}}

<br><br>

**Canonical**: ```http://fhir.de/CodeSystem/dkgev/EntlassungsgrundDritteStelle```

{{render:http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel}}