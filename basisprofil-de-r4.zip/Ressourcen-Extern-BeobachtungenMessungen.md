----
## Beobachtungen, Messungen (Observation)

Für folgende Beobachtungen und Messungen wird innerhalb der Deutschen Basisprofile auf externe Leitfäden verwiesen:

* {{pagelink:Ressourcen-Extern-Observation-Schwangerschaft.md}}
* {{pagelink:Ressourcen-Extern-Observation-Anamnese}}
* {{pagelink:Ressourcen-Extern-Observation-BMI}}