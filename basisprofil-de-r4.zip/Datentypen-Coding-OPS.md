----
### OPS

Bei der Kodierung per [OPS](https://www.dimdi.de/dynamic/de/klassifikationen/ops/) muss das Element Condition.code mit mindestens einem Coding gefüllt sein, das den Anforderungen der OPS-Kodierung genügt. Hierzu sollte beim Einbinden des Coding-Profils in das entsprechende Use-Case-Profil ein Binding auf das OPS ValueSet hinzugefügt werden. Siehe {{pagelink:Terminologie-ValueSets}}.

Die Angabe der OPS-Version (z.B."2019"), aus der ein Code stammt, ist verpflichtend, da OPS nicht versions-stabil ist, d.h. Codes können zwischen den unterschiedlichen Jahrensangaben in der Bedeutung wechseln.

**Name**: CodingICD10GM ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/CodingOPS&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/CodingOPS`

{{tree:http://fhir.de/StructureDefinition/CodingOPS, hybrid}}