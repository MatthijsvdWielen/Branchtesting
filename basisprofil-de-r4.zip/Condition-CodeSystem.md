----
### Diagnosen (Condition)

**Canonical**: ```http://fhir.de/CodeSystem/dimdi/alpha-id```

{{render:http://fhir.de/CodeSystem/dimdi/alpha-id}}

<br><br>

**Canonical**: ```http://fhir.de/CodeSystem/dimdi/icd-10-gm```

{{render:http://fhir.de/CodeSystem/dimdi/icd-10-gm}}