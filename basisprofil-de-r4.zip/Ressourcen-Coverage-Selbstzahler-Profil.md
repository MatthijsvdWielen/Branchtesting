----
### Selbstzahler-Profil

Für die Abbildung eines Selbstzahler-Verhältnisses sind über das Basisprofil hinaus folgende Mindestangaben erforderlich:

**Name**: CoverageDeSel ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/coverage-de-sel&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/coverage-de-sel`

{{tree:http://fhir.de/StructureDefinition/coverage-de-sel, hybrid}}
