# Implementierungsleitfaden FHIR-Basis für das deutsche Gesundheitswesen


**vorgelegt von: HL7 Deutschland**

{{render:Basisprofil-DE-R4/hl7-logo}}

---

Version: 1.0.0 (STU1)

Datum: 17.02.2020

Status: in Abstimmung

Realm: Deutschland

frühere Fassungen: [vgl. Versions-Historie](http://ig.fhir.de/basisprofile-de/)

---

## Inhaltsverzeichnis
{{index:root}}

## Impressum

Dieser Leitfaden ist im Rahmen des Interoperabilitätsforums und den Technischen Komitees von HL7 Deutschland e. V. sowie der entsprechenden Projektgruppen zusammengestellt und unterliegt dem [Abstimmungsverfahren des Interoperabilitätsforums](http://wiki.hl7.de/index.php?title=Abstimmungsverfahren_(Regeln)) und der Technischen Komitees von [HL7 Deutschland e. V.](http://www.hl7.de).

## Ansprechpartner

* Simone Heckmann, Gefyra GmbH, DMI GmbH & Co. KG
* Alexander Zautke, Firely B.V
 
## Disclaimer

* Der Inhalt dieses Dokuments ist öffentlich. Zu beachten ist, dass Teile dieses Dokuments auf FHIR Version R4 beruhen, für die Copyright HL7 International gilt.
* Obwohl diese Publikation mit größter Sorgfalt erstellt wurde, kann HL7 Deutschland keinerlei Haftung für direkten oder indirekten Schaden übernehmen, der durch den Inhalt dieser Spezifikation entstehen könnte.

## Autoren

* Simone Heckmann (SH), Gefyra GmbH, DMI GmbH & Co. KG
* Stefan Lang (SL), Lang Health IT Consulting
* Patrick Werner (PW), MOLIT Institut gGmbH
* Alexander Zautke (AZ), Firely B.V
* Peter Scholz (PS), OSM AG
* Mareike Przysucha (MP), Hochschule Osnabrück

## Copyright-Hinweis, Nutzungshinweise

Copyright © 2016-2019: HL7 Deutschland e. V., Anna-Louisa-Karsch-Str. 2, 10178 Berlin

Der Inhalt dieser Spezifikation ist öffentlich. Die Nachnutzungs- bzw. Veröffentlichungsansprüche sind nicht beschränkt.

Zu den Nutzungsrechten der zugrunde liegenden FHIR-Technologie siehe die [FHIR-Basis-Spezifikation](https://www.hl7.org/fhir/).

Einige verwendete Codesysteme werden von anderen Organisationen herausgegeben und gepflegt. Es gilt das Copyright der dort jeweils aufgeführten Herausgeber (Publisher).

Die FHIR-Profile unterliegen neben dem Abstimmungsverfahren zusätzlich dem etablierten Kurationsverfahren des Technischen Komitees FHIR unter der Leitung von

* Simone Heckmann, Leiterin HL7 Technisches Komitee FHIR, DMI GmbH & Co. KG (Münster), Gefyra GmbH (Münster)
* Alexander Zautke, stellv. Leiter HL7 Technisches Komitee FHIR, Firely B.V (Amsterdam)

## Versions-Historie
* 1.0.0 Ballotierungsversion, Standard zur Probe
* 0.9.x Refactoring und Portierung auf R4, Auflösen der Kommentare aus dem Abstimmungsverfahren
---------------
* 0.2.1 (15.03.2019): Ergänzung der Extension "gender-amtlich-de" in den Patientenprofilen sowie der zugehörigen Terminologie-Ressourcen, ansonsten identisch mit Version 0.2
* 0.2 (16.11.2018): Entwurf für das 2. Kommentierungsverfahren
* 0.1 (15.09.2017): Entwurf für das 1. Kommentierungsverfahren
