----
### Lebenslange Zahnarztnummer (ZANR)

Die ZANR wird für Zahnarztnummern (Zahnarzt-Abrechnungsnummern) verwendet, die von der KZBV bzw. 
den Landesvereinigungen für ihren Abrechnungsbereich herausgegeben werden. 
Die Zahnarztnummer ist 1- bis 6-stellig numerisch.

In FHIR kann die ZANR als Identifier für Practitioner verwendet werden.
Das folgende Profil beschreibt die Abbildung einer ZANR als Identifier:

**Name**: IdentifierZanr ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/identifier-zanr&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/identifier-zanr`

{{tree:http://fhir.de/StructureDefinition/identifier-zanr, hybrid}}

Folgende Constraints sind zu beachten:

@``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/identifier-zanr' for differential.element.constraint select key, severity, human, expression```
			
Bei der Verwendung der Canonical-URL http://fhir.de/NamingSystem/kzv/XX/zahnarztnummer ist 'XX' durch den zweistellig numerischen Code der jeweils zuständigen KZVzu ersetzen.

Die KZV-Codes sind hier zu finden (Seite 77): https://www.gkv-datenaustausch.de/media/dokumente/leistungserbringer_1/zahnaerzte/technische_anlagen___aktuell_1/20170727_TA_Version_3_8_oA.pdf


Beispiel:

```xml
    <identifier>
        <type>
            <coding>
                <system value="http://fhir.de/CodeSystem/identifier-type-de-basis"/>
                <code value="ZANR"/>
            </coding>
        </type>
        <system value="http://fhir.de/NamingSystem/kzv/35/zahnarztnummer" />
        <value value="123456" />
    </identifier>
```