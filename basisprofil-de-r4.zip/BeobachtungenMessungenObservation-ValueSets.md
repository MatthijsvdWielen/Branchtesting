----
### Beobachtungen, Messungen (Observation)

**Canonical**: ```http://fhir.de/ValueSet/UcumVitalsCommonDE```

{{render:http://fhir.de/ValueSet/UcumVitalsCommonDE}}

<br><br>

**Canonical**: ```http://fhir.de/ValueSet/VitalSignDE_Body_Height_Loinc```

{{render:http://fhir.de/ValueSet/VitalSignDE_Body_Height_Loinc}}

<br><br>

**Canonical**: ```http://fhir.de/ValueSet/VitalSignDE_Body_Length_UCUM```

{{render:http://fhir.de/ValueSet/VitalSignDE_Body_Length_UCUM}}

<br><br>

**Canonical**: ```http://fhir.de/ValueSet/VitalSignDE_Body_Weight_Loinc```

{{render:http://fhir.de/ValueSet/VitalSignDE_Body_Weight_Loinc}}

<br><br>

**Canonical**: ```http://fhir.de/ValueSet/VitalSignDE_Body_Weigth_UCUM```

{{render:http://fhir.de/ValueSet/VitalSignDE_Body_Weigth_UCUM}}
