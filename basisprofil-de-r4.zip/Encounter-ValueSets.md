----
### Ambulanter/stationärer Fall / Kontakt (Encounter)

**Canonical**: ```http://fhir.de/ValueSet/dkgev/Aufnahmeart```

{{render:http://fhir.de/ValueSet/dkgev/Aufnahmeart}}