## Prozeduren (Procedure)

Prozeduren im Kontext von FHIR werden als Procedure-Ressource abgebildet. Hierzu existiert ähnlich wie zur Ressource "Patient" kein Deutsches Basisprofil. Hingegen werden folgende allgemeine Vorgaben für Bestandteile der Procedure-Ressource spezifiziert, welche Eigenheiten des Deutschen Gesundheitswesens in Bezug auf Diagnosen abbildet.

{{index:current}}

