----
#### Organisationsinterner Patienten-Identifier (PID)

**Name**: IdentifierPid ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/identifier-pid&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/identifier-pid`

{{tree:http://fhir.de/StructureDefinition/identifier-pid, hybrid}}

Da es beim organisationsinternen Identifier keinen einheitlichen Namensraum gibt, ist hier die Angabe des `type`-Codes "MR" (Medical Record Number) verpflichtend, um die PID einrichtungsübergreifend als solche erkennen zu können.

Jede Einrichtung muss für ihren Namensraum eine NamingSystem-URL festlegen.
Hinweise zur Nomenklatur organisationsinterner `Identifier.system`-URLs siehe {{pagelink: Terminologie-Namensraueme-LokaleNamensraeume}}.

##### Beispiel PID
```xml
    <identifier>
        <type>
            <coding>
                <system value="http://terminology.hl7.org/CodeSystem/v2-0203" />
                <code value="MR" />
            </coding>
        </type>
        <system value="http://mein-krankenhaus.de/fhir/NamingSystem/patient-identifier" />
        <value value="12345678" />
    </identifier>
```
