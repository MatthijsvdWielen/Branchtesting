## Diagnosen (Condition)

Diagnosen im Kontext von FHIR werden als Condition-Ressource abgebildet. Hierzu existiert ähnlich wie zur Ressource "Patient" kein Deutsches Basisprofil. Hingegen werden folgende allgemeine Vorgaben für Bestandteile der Condition-Ressource spezifiziert, welche Eigenheiten des Deutschen Gesundheitswesens in Bezug auf Diagnosen abbildet.

{{index:current}}



