## Ressourcen-Paket

Die in diesem Leitfaden beschriebenen Conformance- und Terminologie-Ressourcen stehen zur freien Verwendung zur Verfügung. Das Simplifier-Projekt enthält stets in aktuellen Arbeitsstand der Deutschen Basisprofile und ist **NICHT** für die Verwendung im produktiven Einsatz geeignet.

Der letzte stabile veröffentlichte Stand kann hier heruntergeladen werden:

* ZIP-Archiv ([Download](http://ig.fhir.de/download/basisprofil-de-r4-0.9.2.zip))
* NPM-Paket ([Installation via FHIR-Paketmanager](https://simplifier.net/packages/de.basisprofil.r4/0.9.2) oder [Download](http://ig.fhir.de/download/de.basisprofil.r4-0.9.2.tgz))

Weitere Informationen für die Verwendung von FHIR-Packages findet sich in der auf dieser [Hilfeseite der FHIR Registry](https://registry.fhir.org/learn).
