----
### Versicherungs-Informationen (Coverage)

**Canonical**: ```http://fhir.de/CodeSystem/versicherungsart-de-basis```

{{render:http://fhir.de/CodeSystem/versicherungsart-de-basis}}

**Canonical**: ```http://fhir.de/CodeSystem/arge-ik/klassifikation```

{{render:http://fhir.de/CodeSystem/arge-ik/klassifikation}}