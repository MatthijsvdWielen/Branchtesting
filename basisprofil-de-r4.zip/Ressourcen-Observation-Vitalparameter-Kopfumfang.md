#### Kopfumfang

**Name**: VitalSignDE_Kopfumfang ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/observation-de-vitalsign-kopfumfang&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/observation-de-vitalsign-kopfumfang`

{{tree:http://fhir.de/StructureDefinition/observation-de-vitalsign-kopfumfang, hybrid}}

{{xml:Example-observation-kopfumfang}}