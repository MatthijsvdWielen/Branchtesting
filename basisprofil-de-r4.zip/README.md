# basisprofile-de-r4

[![Build Status](https://travis-ci.org/hl7germany/basisprofil-de-r4.svg?branch=master)](https://travis-ci.org/hl7germany/basisprofil-de-r4)