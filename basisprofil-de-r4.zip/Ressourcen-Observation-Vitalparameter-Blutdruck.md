#### Blutdruck

**Name**: VitalSignDE_Blutdruck ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/observation-de-vitalsign-blutdruck&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/observation-de-vitalsign-blutdruck`

{{tree:http://fhir.de/StructureDefinition/observation-de-vitalsign-blutdruck, hybrid}}

{{xml:example-observation-blutdruck}}