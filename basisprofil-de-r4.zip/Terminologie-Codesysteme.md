## Codesysteme

Durch das TC FHIR werden FHIR-Repräsentationen für Codesysteme in folgenden Kontexten definiert, sowie die dazuhegörigen Canonical URLs festgelegt:

{{index:current}}