## Beobachtungen, Messungen (Observation)
