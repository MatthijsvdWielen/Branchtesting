# IHE XDS Value Sets

Synchronized from ART-DECOR

Last Updated on 2021-02-12 23:02:19

List of updated files:
* terminologie/ihe/ValueSet-1.2.276.0.76.11.30--20180713131246.xml
* terminologie/ihe/ValueSet-1.2.276.0.76.11.31--20180713132208.xml
* terminologie/ihe/ValueSet-1.2.276.0.76.11.32--20180713132315.xml
* terminologie/ihe/ValueSet-1.2.276.0.76.11.40--20180713132721.xml
* terminologie/ihe/ValueSet-1.2.276.0.76.11.33--20180713132759.xml
* terminologie/ihe/ValueSet-1.2.276.0.76.11.39--20180713132816.xml
* terminologie/ihe/ValueSet-1.2.276.0.76.11.34--20180713132843.xml
* terminologie/ihe/ValueSet-1.2.276.0.76.11.59--20180713162125.xml
* terminologie/ihe/ValueSet-1.2.276.0.76.11.58--20180713162142.xml
* terminologie/ihe/ValueSet-1.2.276.0.76.11.38--20180713162205.xml
* terminologie/ihe/ValueSet-1.2.276.0.76.11.36--20181001183306.xml
* terminologie/ihe/ValueSet-1.2.276.0.76.11.35--20181214170712.xml
* terminologie/ihe/ValueSet-1.2.276.0.76.11.37--20190517134631.xml
