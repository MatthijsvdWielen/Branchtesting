----
### diagnosis-role

**Canonical**: ```http://fhir.de/CodeSystem/diagnosis-role-supplement```

{{render:http://fhir.de/CodeSystem/diagnosis-role-supplement}}