------

### Diagnosetypen und -Rangfolgen

Grundsätzlich gilt zu beachten, dass Attribute wie "Aufnahme- oder Entlass-Diagnose", sowie Rangfolgen von Diagnosen stets im Kontext eines Behandlungsfalles zu sehen sind.
Sie werden daher als Eigenschaft des [Encounters](http://hl7.org/fhir/encounter.html) modelliert.

Die Kodierung des Diagnose-Typs erfolgt über Encounter.diagnosis.use.
Die Unterscheidung zwischen Haupt- und Nebendiagnose ist per Encounter.diagnosis.rank anzugeben.


#### Beispiel: Entlassdiagnose
```xml
<diagnosis>
    <condition>
        <reference value="Condition/example"/>
    </condition>
    <use>
        <coding>
            <system value="http://terminology.hl7.org/CodeSystem/diagnosis-role"/>
            <code value="DD"/>
            <display value="Entlassdiagnose"/>
        </coding>
    </use>
    <rank value="1"/>
</diagnosis>
```
#### Beispiel: Hauptdiagnose
```xml
  <diagnosis>
    <condition>
      <reference value="Condition/example"/>
    </condition>
    <use>
      <coding>
        <system value="http://terminology.hl7.org/CodeSystem/diagnosis-role"/>
        <code value="CC"/>
        <display value="Hauptdiagnose"/>
      </coding>
    </use>
    <rank value="1"/>
  </diagnosis>
```

