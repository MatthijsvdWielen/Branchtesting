----
### marital-status

**Canonical**: ```http://fhir.de/CodeSystem/marital-status-supplement```

{{render:http://fhir.de/CodeSystem/marital-status-supplement}}