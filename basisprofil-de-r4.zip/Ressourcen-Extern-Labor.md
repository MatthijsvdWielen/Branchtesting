----
## Labor (Observation, ServiceRequest, DiagnosticReport)

Für die Abbildung von Labordaten in FHIR verweist das TC auf das entsprechende Kerndatensatz-Modul der MI-Initiative https://simplifier.net/medizininformatikinitiative-laborprofile

Diskussion im Chat: https://chat.fhir.org/#narrow/stream/179307-german.2Fmi-initiative