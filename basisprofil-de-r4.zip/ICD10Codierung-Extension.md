## ICD-10 Codierung

Folgende Extensions werden im Kontext der Abbildung einer Kodierung nach [ICD-10 GM](https://www.dimdi.de/dynamic/de/klassifikationen/icd/icd-10-gm/) definiert:


----

**Name**: Extension-seitenlokalisation ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/seitenlokalisation&scope=de.basisprofil.r4@1.0.0-alpha1))

**Beschreibung**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/seitenlokalisation' select description```

**Canonical**: `http://fhir.de/StructureDefinition/seitenlokalisation`

**Kontext**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/seitenlokalisation' for context select expression```

{{tree:http://fhir.de/StructureDefinition/seitenlokalisation, snapshot}}

**Hinweise**: Es ist zu beachten, dass laut ICD-10 GM die Angabe der Seitenlokalisation ein Bestand des Codes ist. Somit sollte die Kodierung i.d.R. auf Condition.code.coding erfolgen. Condition.bodySite sollte **nicht** verwendet werden.

| Hinweis | Under Construction! |
|---------|---------------------|
| {{render:Warning}} | Das vorliegende Profil enthält Verweise auf CodeSysteme / NamingSystems der Kassenärztliche Bundesvereinigung (KBV). Diese Ressourcen werden nicht als Teil der Deutschen Basisprofile veröffentlicht und sind separat zu Validierungszwecke o.Ä. in die entsprechenden Projekte einzubinden. Siehe [fhir.kbv.de](fhir.kbv.de).|

**Beispiel**:

```
<extension url="http://fhir.de/StructureDefinition/seitenlokalisation" >
    <valueCoding>
        <system value="https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_SEITENLOKALISATION" />
        <value value="B" />
        <display value="beiderseits" />
    </valueCoding>
</extension>
```

----

**Name**: Extenstion-ICD10GMAusrufezeichen ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/icd-10-gm-ausrufezeichen&scope=de.basisprofil.r4@1.0.0-alpha1))

**Beschreibung**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/icd-10-gm-ausrufezeichen' select description```

**Canonical**: `http://fhir.de/StructureDefinition/icd-10-gm-ausrufezeichen`

**Kontext**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/icd-10-gm-ausrufezeichen' for context select expression```

{{tree:http://fhir.de/StructureDefinition/icd-10-gm-ausrufezeichen, snapshot}}

**Hinweise**: Siehe Kodierungshinweise für ICD-10 GM - {{pagelink:Datentypen-ICD-10GM-Coding}}

**Beispiel**:

```
<extension url="http://fhir.de/StructureDefinition/icd-10-gm-ausrufezeichen">
    <valueCoding>
        <system value="http://fhir.de/CodeSystem/dimdi/icd-10-gm" />
        <version value="2019" />
        <code value="U69.32" />
    </valueCoding>
</extension>
```

----

**Name**: Extension-ICD10GMDiagnosesicherheit ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/icd-10-gm-diagnosesicherheit&scope=de.basisprofil.r4@1.0.0-alpha1))

**Beschreibung**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/icd-10-gm-diagnosesicherheit' select description```

**Canonical**: `http://fhir.de/StructureDefinition/icd-10-gm-diagnosesicherheit`

**Kontext**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/icd-10-gm-diagnosesicherheit' for context select expression```

{{tree:http://fhir.de/StructureDefinition/icd-10-gm-diagnosesicherheit, snapshot}}

**Constraints**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/icd-10-gm-diagnosesicherheit' for differential.element.constraint select key,severity,human, expression```

**Hinweise**: Siehe Kodierungshinweise für ICD-10 GM - {{pagelink:Datentypen-ICD-10GM-Coding}}

**Beispiel**:

```
<extension url="http://fhir.de/StructureDefinition/icd-10-gm-diagnosesicherheit">
    <valueCoding>
        <system value="https://fhir.kbv.de/CodeSystem/KBV_CS_SFHIR_ICD_DIAGNOSESICHERHEIT" />
        <code value="G" />
        <display value="gesicherte Diagnose" />
    </valueCoding>
</extension>
```

----

**Name**: Extension-ICD10GMPrimaercode ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/icd-10-gm-primaercode&scope=de.basisprofil.r4@1.0.0-alpha1))

**Beschreibung**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/icd-10-gm-primaercode' select description```

**Canonical**: `http://fhir.de/StructureDefinition/icd-10-gm-primaercode`

**Kontext**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/icd-10-gm-primaercode' for context select expression```

{{tree:http://fhir.de/StructureDefinition/icd-10-gm-primaercode, snapshot}}

**Hinweise**: Siehe Kodierungshinweise für ICD-10 GM - {{pagelink:Datentypen-ICD-10GM-Coding}}

**Beispiel**:

```
<extension url="http://fhir.de/StructureDefinition/icd-10-gm-primaercode">
    <valueCoding>
        <system value="http://fhir.de/CodeSystem/dimdi/icd-10-gm" />
        <version value="2019" />
        <code value="F16.1" />
        <display value="Psychische und Verhaltensstörungen durch Halluzinogene : Schädlicher Gebrauch" />
    </valueCoding>
</extension>
```

----

**Name**: Extension-ICD10GMManifestationscode ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/icd-10-gm-manifestationscode&scope=de.basisprofil.r4@1.0.0-alpha1))

**Beschreibung**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/icd-10-gm-manifestationscode' select description```

**Canonical**: `http://fhir.de/StructureDefinition/icd-10-gm-manifestationscode`

**Kontext**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/icd-10-gm-manifestationscode' for context select expression```

{{tree:http://fhir.de/StructureDefinition/icd-10-gm-manifestationscode, snapshot}}

**Hinweise**: Siehe Kodierungshinweise für ICD-10 GM - {{pagelink:Datentypen-ICD-10GM-Coding}}

**Beispiel**:

```
<extension url="http://fhir.de/StructureDefinition/icd-10-gm-manifestationscode">
    <valueCoding>
        <system value="http://fhir.de/CodeSystem/dimdi/icd-10-gm" />
        <version value="2019" />
        <code value="F71" />
        <display value="Mittelgradige Intelligenzminderung" />
    </valueCoding>
</extension>
```