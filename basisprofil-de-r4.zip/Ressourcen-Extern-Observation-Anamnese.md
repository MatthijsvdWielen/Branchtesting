----
### Anamnese

{{index:Anamnese}}
