----
## Medikation (Medication)

Für die Abbildung von Medikationsdaten in FHIR verweist das TC auf das entsprechende Kerndatensatz-Modul der MI-Initiative: https://simplifier.net/MedizininformatikInitiative-ModulMedikation

Diskussion im Chat: https://chat.fhir.org/#narrow/stream/179307-german.2Fmi-initiative