## Extensions

Nachfolgend werden alle Extensions, die innerhalb der Deutschen Basisprofile spezifiziert werden, dokumentiert. Extensions welche bereits in der FHIR-Kernspezfikation definiert werden, können in der [FHIR Extension Registry](http://hl7.org/fhir/extensibility-registry.html) von HL7 International eingesehen werden.

In folgenden Kontexten werden Extensions durch die Deutschen Basisprofile verwendet:

{{index:current}}