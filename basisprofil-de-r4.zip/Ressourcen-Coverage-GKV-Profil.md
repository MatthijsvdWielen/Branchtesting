----
### GKV-Profil

Für die Abbildung eines gesetzlichen Versicherungsverhältnisses sind die Informationen auf der elektronischen Versichertenkarte (eGK) maßgeblich.

Diese Informationen werden über spezielle Extensions abgebildet, die Informationen den Einlesevorgang der eKG sowie dem Inhalt des darauf gespeicherten Datensatzes enthalten:

**Name**: CoverageDeGkv ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/coverage-de-gkv&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/coverage-de-gkv`

{{tree:http://fhir.de/StructureDefinition/coverage-de-gkv, hybrid}}

### Übersicht über die Extensions

Siehe {{pagelink:Coverage-Extension}}.

### Beispiel

Folgendes Beispiel deckt das GKV-Profil vollständig ab:

{{xml:Coverage-example}}