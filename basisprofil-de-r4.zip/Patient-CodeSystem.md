----
### PatientIn (Patient)

**Canonical**: ```http://fhir.de/CodeSystem/gender-amtlich-de```

{{render:http://fhir.de/CodeSystem/gender-amtlich-de}}