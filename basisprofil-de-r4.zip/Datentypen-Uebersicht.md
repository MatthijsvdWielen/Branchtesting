# Datentypen

Für folgendende Datentypen werden verpflichtende Angaben innerhalb der Deutschen Basisprofile spezifiziert:

{{index:current}}