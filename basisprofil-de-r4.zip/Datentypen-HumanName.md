## HumanName

Das Datentyp-Profil für 'HumanName' wird im Kontext von der "Patient"-Ressource beschrieben. Siehe Abschnitt {{pagelink:Ressourcen-Patient-Name}}. Das Datentyp-Profil kann jedoch in allen anderen Kontexten in denen ein HumanName erlaubt ist verwendet werden (InsurancePlan, Organization, Patient, Person, Practitioner and RelatedPerson).