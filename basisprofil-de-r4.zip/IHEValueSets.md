----
### IHE-ValueSets

**Canonical**: ```http://ihe-d.de/ValueSets/IHEXDSauthorRole```

{{render:http://ihe-d.de/ValueSets/IHEXDSauthorRole}}

<br><br>

**Canonical**: ```http://ihe-d.de/ValueSets/IHEXDSauthorSpeciality```

{{render:http://ihe-d.de/ValueSets/IHEXDSauthorSpeciality}}

<br><br>

**Canonical**: ```http://ihe-d.de/ValueSets/IHEXDSclassCode```

{{render:http://ihe-d.de/ValueSets/IHEXDSclassCode}}

<br><br>

**Canonical**: ```http://ihe-d.de/ValueSets/IHEXDSconfidentialityCode```

{{render:http://ihe-d.de/ValueSets/IHEXDSconfidentialityCode}}

<br><br>

**Canonical**: ```http://ihe-d.de/ValueSets/IHEXDSeventCodeList```

{{render:http://ihe-d.de/ValueSets/IHEXDSeventCodeList}}

<br><br>

**Canonical**: ```http://ihe-d.de/ValueSets/IHEXDSeventCodeList```

{{render:http://ihe-d.de/ValueSets/IHEXDSformatCodeDE}}

<br><br>

**Canonical**: ```http://ihe-d.de/ValueSets/IHEXDShealthcareFacilityTypeCode```

{{render:http://ihe-d.de/ValueSets/IHEXDShealthcareFacilityTypeCode}}

<br><br>

**Canonical**: ```http://ihe-d.de/ValueSets/IHEXDSpracticeSettingCode```

{{render:http://ihe-d.de/ValueSets/IHEXDSpracticeSettingCode}}

<br><br>

**Canonical**: ```http://ihe-d.de/ValueSets/IHEXDStypeCode```

{{render:http://ihe-d.de/ValueSets/IHEXDStypeCode}}

<br><br>

**Canonical**: ```http://ihe-d.de/ValueSets/IHEXDScontentTypeCode```

{{render:http://ihe-d.de/ValueSets/IHEXDScontentTypeCode}}

<br><br>

**Canonical**: ```http://ihe-d.de/ValueSets/IHEXDScodeList```

{{render:http://ihe-d.de/ValueSets/IHEXDScodeList}}

<br><br>

**Canonical**: ```http://art-decor.org/fhir/ValueSet/1.2.276.0.76.11.58--20180713162142```

{{render:http://art-decor.org/fhir/ValueSet/1.2.276.0.76.11.58--20180713162142}}

<br><br>

**Canonical**: ```http://art-decor.org/fhir/ValueSet/1.2.276.0.76.11.58--20180713162142```

{{render:http://art-decor.org/fhir/ValueSet/1.2.276.0.76.11.59--20180713162125}}

<br><br>