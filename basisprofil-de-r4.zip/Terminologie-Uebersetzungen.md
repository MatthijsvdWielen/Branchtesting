## Codesystem-Übersetzungen

Deutsche Übersetzungen für international genutzte CodeSysteme werden diesem Leitfaden als `CodeSystem`s vom Typ "supplement" beigefügt.

Die Supplements können von Terminologie-Servern genutzt werden, um bei der ValueSet-Expansion deutsche Anzeigetexte für `display` zu verwenden anstelle der englischen Texte aus dem zugrunde liegenden CodeSystem. 

Folgende CodeSystem Supplements werden in den Deutschen Basisprofilen publiziert:

{{index:current}}