------------

### Geschlecht

#### Beispiel: weiblich
```xml
<gender value="female"/>
```

#### Beispiel: männlich
```xml
<gender value="male"/>
```
#### Geschlechtskennzeichen "unbestimmt" und "divers"
Für die Geschlechtskennzeichen "unbestimmt" und "divers" ist der code "other" zu verwenden:

```xml
<gender value="other"/>
```

Falls ein administratives Geschlecht 'divers' abzubilden ist (z.B. da dieses Geschlecht auf offiziellen Ausweisen eingetragen ist) muss eine Differenzierung zwischen 'other' und 'divers' als positiver Geschlechtseintrag erfolgen. Hierfür ist die 'other-amtlich'-Extension zu verwenden. Siehe Extensions-Dokumentation für {{pagelink:Geschlecht-Extension}}.

#### Beispiel: divers
```xml
<gender value="other">
    <extension url="http://fhir.de/StructureDefinition/gender-amtlich-de"/>
        <valueCoding>
            <system value="http://fhir.de/CodeSystem/gender-amtlich-de"/>
            <code value="D"/>
        </valueCoding>
    </extension>
</gender>
```

Für Extensions zur Differenzierung von z.B. Gender Identity, Sex Assigned At Brith, siehe [Patient Gender and Sex](https://www.hl7.org/fhir/patient.html#gender)

#### Beispiel: unbestimmt
```xml
<gender value="other">
    <extension url="http://fhir.de/StructureDefinition/gender-amtlich-de"/>
        <valueCoding>
            <system value="http://fhir.de/CodeSystem/gender-amtlich-de"/>
            <code value="X"/>
        </valueCoding>
    </extension>
</gender>
```