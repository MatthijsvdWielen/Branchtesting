<div class="notice notice-border notice-background">
  <img src="https://www.hl7.org/fhir/assets/images/dragon.png" title="A cute kitten" class="notice" />
  <p>Future versions of this specification may impose different rules than described here as this topic is still heavily being discussed. Implementers and authors of implementation guides should be aware of ongoing work in this area.</p>
  <p>Implementer feedback is welcome on the issue tracker or <a href="chat.fhir.org">chat.fhir.org</a></p>
</div>