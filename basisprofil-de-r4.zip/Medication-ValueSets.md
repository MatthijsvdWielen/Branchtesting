----
### Medikation (Medication)

**Canonical**: ```http://fhir.de/ValueSet/dimdi/atc```

{{render:http://fhir.de/ValueSet/dimdi/atc}}

<br><br>

**Canonical**: ```http://fhir.de/ValueSet/ask```

{{render:http://fhir.de/ValueSet/ask}}

<br><br>

**Canonical**: ```http://fhir.de/ValueSet/ifa/pzn```

{{render:http://fhir.de/ValueSet/ifa/pzn}}