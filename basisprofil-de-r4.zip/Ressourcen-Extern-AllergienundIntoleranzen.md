----
## Allergien und Intoleranzen (AllergyIntolerance)

Empfohlen wird die Verwendung des Profils aus dem International Patient Summary (IPS).

http://hl7.org/fhir/uv/ips/StructureDefinition-AllergyIntolerance-uv-ips.html

##### Mitreden!
* https://chat.fhir.org/#narrow/stream/179183-german-(d-a-ch)/topic/Basisprofil.20AllergyIntolerance.20und.20ATC