## ValueSets

Durch das TC FHIR werden FHIR-Repräsentationen für ValueSets in folgenden Kontexten definiert, sowie die dazuhegörigen Canonical URLs festgelegt:

{{index:current}}