## PatientIn (Patient)

Im Gegensatz zu den Deutschen Basisprofile für die FHIR Version STU3 gibt es in der vorliegenden Version der Deutschen Basisprofile für FHIR R4 kein Patient-Profil mehr. Die Gründe dafür sind unter dem Abschnitt {{pagelink:Anwendungshinweise-FAQ}} erläutert.