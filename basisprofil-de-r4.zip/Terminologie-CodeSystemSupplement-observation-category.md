----
### observation-category

**Canonical**: ```http://fhir.de/CodeSystem/observation-category-supplement```

{{render:http://fhir.de/CodeSystem/observation-category-supplement}}