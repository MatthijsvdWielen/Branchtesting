## Ambulanter/stationärer Fall / Kontakt (Encounter)

Der Begriff "Fall" gruppiert im Sprachgebrauch verschiedene Konzepte, die in FHIR durch unterschiedliche Ressourcen repräsentiert werden:

1. **Aufenthalt/Besuch/Kontakt:** Der stationäre Aufenthalt oder ambulante Kontakt eines Patienten in einer Gesundheitseinrichtung wird in FHIR durch die Ressource `Encounter` abgebildet.

    Für folgenden Elemente des Encounters werden innerhalb der Deutschen Basisprofile Empfehlungen für ValueSets-Bindings herausgegeben. Siehe {{pagelink:Terminologie-CodeSysteme}}

    - Encounter.serviceType - Fachabteilungsschlüssel
    - Encounter.reasonCode (Extension) - Aufnahmegrund
    - Encounter.hospitalization.admitSource - Aufnahmeanlass
    - Encounter.hospitalization.dischargeDisposition (Extension) - Entlassungsgrund<br><br>

2. **Abrechnungsfall:** Der Fall im Sinne einer Gruppierung von medizinischen Leistungen, die in einem gemeinsamen Kontext abgerechnet werden, sind in FHIR durch die Ressource `Account` repräsentiert. Ein Abrechnungsfall kann mehrere `Encounter` umfassen (z.B. vorstationärer Besuch, stationärer Aufenthalt und nachstationäre Besuche)

3. **Medizinischer Fall:** Der medizinische Fall gruppiert Informationen, die im Kontext einer gemeinsamen (Dauer-)Diagnose stehen und wird in FHIR durch die `EpisodeOfCare` dargestellt.

Für die Ausgestaltung des Encounters im stationären Kontext wird auf das [Basismodul 'Fall' der Medizininformatik-Initative](https://simplifier.net/guide/medizininformatikinitiative-modulfall-implementationguide/igmiikdsmodulfall) verwiesen.