#### Herzfrequenz

**Name**: VitalSignDE_Herzfrequenz ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/observation-de-vitalsign-herzfrequenz&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/observation-de-vitalsign-herzfrequenz`

{{tree:http://fhir.de/StructureDefinition/observation-de-vitalsign-herzfrequenz, hybrid}}

{{xml:example-observation-herzfrequenz}}