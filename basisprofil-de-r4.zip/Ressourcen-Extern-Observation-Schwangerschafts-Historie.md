#### Schwangerschafts-Historie

Empfohlen wird die Verwendung des Profils aus dem International Patient Summary (IPS)

http://hl7.org/fhir/uv/ips/StructureDefinition-Observation-pregnancy-outcome-uv-ips.html