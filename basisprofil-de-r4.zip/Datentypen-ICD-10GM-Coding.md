----
### ICD-10 GM

Bei der Kodierung per [ICD-10-GM](https://www.dimdi.de/dynamic/de/klassifikationen/icd/icd-10-gm/) muss das Element Condition.code mit mindestens einem Coding gefüllt sein, das den Anforderungen der ICD-Kodierung genügt. Hierzu sollte beim Einbinden des Coding-Profils in das entsprechende Use-Case-Profil ein Binding auf das ICD-10-GM ValueSet hinzugefügt werden. Siehe {{pagelink:Terminologie-ValueSets}}.

Die Angabe der ICD-Version (z.B."2019"), aus der ein Code stammt, ist verpflichtend, das ICD-GM nicht versions-stabil ist, d.h. Codes können zwischen den unterschiedlichen Jahrensangaben in der Bedeutung wechseln.

**Name**: CodingICD10GM ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/CodingICD10GM&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/CodingICD10GM`

{{tree:http://fhir.de/StructureDefinition/CodingICD10GM, hybrid}}