----
### Weitere ValueSets

**Canonical**: ```http://fhir.de/ValueSet/iso/bundeslaender```

{{render:http://fhir.de/ValueSet/iso/bundeslaender}}

<br><br>

**Canonical**: ```http://fhir.de/ValueSet/identifier-type-de-basis```

{{render:http://fhir.de/ValueSet/identifier-type-de-basis}}