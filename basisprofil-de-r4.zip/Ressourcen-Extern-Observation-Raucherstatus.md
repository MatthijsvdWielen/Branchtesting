#### Raucherstatus

Empfohlen wird die Verwendung des Profils aus dem International Patient Summary (IPS)

http://hl7.org/fhir/uv/ips/StructureDefinition-Observation-tobaccouse-uv-ips.html