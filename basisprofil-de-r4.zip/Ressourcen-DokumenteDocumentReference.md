## Dokumente (DocumentReference)

----

### Dokumentenaustausch
Für den (einrichtungsübergreifenden) Dokumentenaustausch eigent sich das [IHE-MHD-Profil](https://wiki.ihe.net/index.php/Mobile_access_to_Health_Documents_(MHD)), das die Akteure Document-Source, Document-Recipient, Document-Provider und Document-Consumer beschreibt.

Grundsätzlich ist auch bei zunächst rein interner Nutzung dennoch die Orientierung an dem in MHD publizierten Document-Reference-Profil empfohlen, um Instanzen zu erzeugen, die später in einem MHD-Umfeld (oder über Adapter auch in einem XDS-Umfeld) genutzt werden können.

Die MHD-Profile sind als FHIR ImplementationGuide unter der Domain von HL7 Int. veröffentlicht. Siehe http://build.fhir.org/ig/IHE/ITI.MHD/

----

### Typisierung und Klassifizierung

Für die Klassifikation und Typisierung von Dokumenten sollten die von IHE-Deutschland publizierten Class- und Typecodes verwendet werden.

[IHE-TypeCode-Valueset in Art-Decor](https://art-decor.org/art-decor/decor-valuesets--ihede-?id=1.2.276.0.76.11.38&effectiveDate=2018-07-13T16:22:05&language=de-DE)

[IHE-ClassCode-ValueSet in Art-Decor](https://art-decor.org/art-decor/decor-valuesets--ihede-?id=1.2.276.0.76.11.32&effectiveDate=2018-07-13T13:23:15&language=de-DE)

Diese ValueSets werden als FHIR ValueSet Ressource innerhalb der Deutschen Basisprofile publiziert. Siehe {{pagelink:Terminologie-ValueSets}}.

Für eine feingranularere Unterscheidung klinischer Dokumenttypen, kommt zusätzlich die vom DVMD publizierte Klinische Dokumentenliste (KDL) in Frage, die einschließlich der Mappings auf IHE-Class- und Typecodes als FHIR-Ressourcen publiziert ist:
https://simplifier.net/KDL

Ein primär nach KDL typisiertes Dokument mit zusätzlichen Mappings nach IHE-Class- und TypeCode, hätte dann Beispielsweise folgende Attribute für `type` und `category`:

```xml
<type>
	<coding>
		<system value="http://dvmd.de/fhir/CodeSystem/kdl" />
		<code value="DG060111" />
		<display value="EKG-Auswertung" />
	</coding>
	<coding>
		<system value="http://ihe-d.de/CodeSystems/IHEXDStypeCode" />
		<code value="FUNK" />
		<display value="Ergebnisse Funktionsdiagnostik" />
	</coding>
</type>
<category>
	<coding>
		<system value="http://ihe-d.de/CodeSystems/IHEXDSclassCode" />
		<code value="BEF" />
		<display value="Befund" />
	</coding>
</category>
```

