#### Atemfrequenz

**Name**: VitalSignDE_Atemfrequenz ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/observation-de-vitalsign-sauerstoffsaettigung&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/observation-de-vitalsign-atemfrequenz`

{{tree:http://fhir.de/StructureDefinition/observation-de-vitalsign-atemfrequenz, hybrid}}

{{xml:example-observation-atemfrequenz}}
