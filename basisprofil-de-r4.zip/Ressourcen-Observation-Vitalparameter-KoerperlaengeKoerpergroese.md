#### Körperlänge/Körpergröße

**Name**: VitalSignDE_Koerpergroesse ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/observation-de-vitalsign-koerpergroesse&scope=de.basisprofil.r4@1.0.0-alpha1)

**Canonical**: `http://fhir.de/StructureDefinition/observation-de-vitalsign-koerpergroesse`

{{tree:http://fhir.de/StructureDefinition/observation-de-vitalsign-koerpergroesse, hybrid}}

{{xml:Example-koerpergroesse}}