----
### Medikation (Medication)

**Canonical**: ```http://fhir.de/CodeSystem/dimdi/atc```

{{render:http://fhir.de/CodeSystem/dimdi/atc}}

<br><br>

**Canonical**: ```http://fhir.de/CodeSystem/ask```

{{render:http://fhir.de/CodeSystem/ask}}

<br><br>

**Canonical**: ```http://fhir.de/CodeSystem/ifa/pzn```

{{render:http://fhir.de/CodeSystem/ifa/pzn}}

<br><br>

**Canonical**: ```http://fhir.de/CodeSystem/edqm/dose-form```

{{render:http://fhir.de/CodeSystem/edqm/dose-form}}