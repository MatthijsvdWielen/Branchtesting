----
### EBM-Ziffern

Das folgende Profil stellt die Dokumentation einer erbrachten Leistung gemäß EBM-Katalog dar:

**Name**: ChargeItemEBM ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/chargeitem-de-ebm&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/chargeitem-de-ebm`

{{tree:http://fhir.de/StructureDefinition/chargeitem-de-ebm, hybrid}}

Beispiel:
{{xml:Basisprofil-DE-R4/ChargeItem-example}}