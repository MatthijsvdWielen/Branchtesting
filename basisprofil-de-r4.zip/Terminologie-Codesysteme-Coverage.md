----
### Versicherungs-Informationen (Coverage)

**Canonical**: ```http://fhir.de/CodeSystem/versicherungsart-de-basis```

{{render:http://fhir.de/CodeSystem/versicherungsart-de-basis}}