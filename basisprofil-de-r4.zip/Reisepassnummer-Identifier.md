----
### Reisepassnummer

Für die Abbildung einer Reisepassnummer kann folgendes Identifier-Profil verwendet werden:

**Name**: IdentifierVknr ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/identifier-reisepassnummer&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/identifier-reisepassnummer`

{{tree:http://fhir.de/StructureDefinition/identifier-reisepassnummer, hybrid}}

```xml
    <identifier>
        <type>
            <coding>
                <system value="http://terminology.hl7.org/CodeSystem/v2-0203"/>
                <code value="PPN"/>
            </coding>
        </type>
        <system value="http://hl7.org/fhir/sid/passport-DEU" />
        <value value="12345689" />
    </identifier>
```