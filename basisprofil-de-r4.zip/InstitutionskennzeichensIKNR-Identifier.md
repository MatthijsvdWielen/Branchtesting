----
### Institutionskennzeichens (IKNR)

Als eindeutiges Merkmal zur Identifizierung von Vertragspartnern, die für die Sozialversicherungsträger Leistungen erbringen wird die IKNR durch die [Arbeitsgemeinschaft Institutionskennzeichen](https://www.dguv.de/arge-ik/index.jsp) vergeben. 

**Name**: IdentifierPkv ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/identifier-iknr&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/identifier-iknr`

{{tree:http://fhir.de/StructureDefinition/identifier-iknr, hybrid}}

Folgende Constraints sind zu beachten:

@``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/identifier-iknr' for differential.element.constraint select key, severity, human, expression```

```xml
    <identifier>
        <type>
            <coding>
                <system value="http://terminology.hl7.org/CodeSystem/v2-0203"/>
                <code value="XX"/>
            </coding>
        </type>
        <system value="http://fhir.de/NamingSystem/arge-ik/iknr">
        <value value="16081989" />
    </identifier>
```