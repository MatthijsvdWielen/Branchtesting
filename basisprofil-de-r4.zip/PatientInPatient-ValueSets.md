----
### PatientIn (Patient)

**Canonical**: ```http://fhir.de/ValueSet/gender-amtlich-de```

{{render:http://fhir.de/ValueSet/gender-amtlich-de}}