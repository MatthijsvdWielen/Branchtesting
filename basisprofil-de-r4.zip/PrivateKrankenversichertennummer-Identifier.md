----
#### Private Krankenversichertennummer

Bei privaten Versicherungen ist die NamingSystem-URL in den meisten Fällen nicht bekannt oder nicht definiert. Da jede Versicherung ihren eigenen Nummernkreis verwendet, sind Versichertennummern ohne Angabe der Versicherung jedoch nicht eindeutig.

In diesem Fall ist das Element `Identifier.assigner` zu verwenden, um mindestens den Namen, idealerweise zusätzlich die IK-Nummer der PKV anzugeben.

Ohne Angabe einer NamingSystem-URL in `Identifier.system` ist es jedoch nicht möglich, einen [Token-Suchparameter](http://hl7.org/implement/standards/fhir/search.html#token) zu definieren, der zuverlässig eindeutige Ergebnisse liefert.
Falls dies in einem konkreten Szenario zu Problemen führt, bitten wir um [Feedback im FHIR-Chat](https://chat.fhir.org/#narrow/stream/179183-german-(d-a-ch)/topic/NamingSystem.20f.C3.BCr.20PKV.20Nummern)

**Name**: IdentifierPkv ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/identifier-pkv&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/identifier-pkv`

{{tree:http://fhir.de/StructureDefinition/identifier-pkv, hybrid}}

##### Beispiel PKV-Nummer

```xml
    <identifier>
        <type>
            <coding>
                <system value="http://fhir.de/CodeSystem/identifier-type-de-basis"/>
                <code value="PKV"/>
            </coding>
        </type>
        <value value="123456" />
        <assigner>
            <identifier value="http://fhir.de/NamingSystem/arge-ik/iknr"/>
            <value value="168140346"/>
            <display value="Allianz"/>
        </assigner>
    </identifier>
```

