## Extension - Datentyp-Profil 'Address'

Folgende Extensions werden im Kontext des [FHIR Datentyps 'Addresse'](https://www.hl7.org/fhir/datatypes.html#Address) definiert:

----

**Name**: Extension-address-ags ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/destatis/ags&scope=de.basisprofil.r4@1.0.0-alpha1))

**Beschreibung**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/destatis/ags' select description```

**Canonical**: `http://fhir.de/StructureDefinition/destatis/ags`

**Kontext**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/destatis/ags' for context select expression```

{{tree:http://fhir.de/StructureDefinition/destatis/ags, snapshot}}

**Hinweise**: n/A

**Beispiel**:

```
<extension url="http://fhir.de/StructureDefinition/destatis/ags" >
    <valueCoding>
        <system value="http://fhir.de/NamingSystem/destatis/ags" />
        <value value="03254021" />
    </valueCoding>
</extension>
```

----