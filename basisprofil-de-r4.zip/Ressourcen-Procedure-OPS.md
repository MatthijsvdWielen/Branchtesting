----
### OPS

Einige Besonderheiten müssen bei der Erfassung einer Kodierung per OPS beachtet werden. Hintergrundinformationen zu OPS werden durch das BfArM herausgegeben. Siehe [Übersicht ICD-10 GM](https://www.dimdi.de/dynamic/de/klassifikationen/ops/) oder [Basiswissen Kodieren, 2010 (.pdf)](https://www.dimdi.de/static/.downloads/deutsch/basiswissen-kodieren-2010.pdf).

Ein OPS Code kann innerhalb eines Coding-Elementes in FHIR erfasst werden. Hierzu auf folgendes Datentyp-Profil verwiesen: {{pagelink:Datentypen-Coding-OPS}}.

Um die Kategorisierung von OPS Prozeduren zu harmonisieren wird auf folgende ConceptMap mit einem Mapping der OPS Klassentitel auf SNOMED-CT verwiesen. Dieses Mapping sollte für Procedure.category verwendet werden. Siehe {{pagelink:Terminologie-ConceptMaps}}.