-----
### VitalParameter

Innerhalb der Deutschen Basisprofile werden Profile für den Ressourcen-Typ 'Observation' spezifiziert welche genutzt werden können um Vitalparameter und Körpermaße zu kodieren.

Diese Profile sind angelehnt an die Internationlen [VitalSign Profile](https://www.hl7.org/fhir/observation-vitalsigns.html) enthalten jedoch technische Korrekturen (Verbessertes Slicing und korregierte FHIRPath-Expressions) oder Einschränkungen auf in Deutschland gebräuchliche Maßeinheiten.

Folgende Observation-Profile wurden in diesem Zusammenhang abgestimmt:

{{index:VitalParameter}}