----
## Pflegebericht

Für die Abbildung von pflegerischen Informationen im Rahmen des ePflegeberichts verweist das TC FHIR auf den Implementierungsleitfaden der Hochschule Osnabrück.

https://simplifier.net/ePflegebericht/

Diskussionen finden im [Chat](https://chat.fhir.org/#narrow/stream/179183-german-(d-a-ch)) statt.