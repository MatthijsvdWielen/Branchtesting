----
### Vertragskassennummer (VKNR)

Die Vertragskassennummer der Kassenärztlichen Vereinigungen (VKNR) identifiziert Krankenkassen für Abrechnungszwecke. Für eine Abbildung der VKNR kann folgendes Profil verwendet werden:

**Name**: IdentifierVknr ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/identifier-vknr&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/identifier-vknr`

{{tree:http://fhir.de/StructureDefinition/identifier-vknr, hybrid}}

```xml
    <identifier>
        <type>
            <coding>
                <system value="http://terminology.hl7.org/CodeSystem/v2-0203"/>
                <code value="NIIP"/>
            </coding>
        </type>
        <system value="http://fhir.de/NamingSystem/kbv/vknr" />
        <value value="12345689" />
    </identifier>
```

