----
### SNOMED-CT / OPS Mapping

Für das Mapping von OPS-Klassentiteln auf SNOMED-CT wird folgende Concept-Map definiert:

**Canonical**: ```http://fhir.de/ConceptMap/OPS-SNOMED-Category```

{{render:http://fhir.de/ConceptMap/OPS-SNOMED-Category}}