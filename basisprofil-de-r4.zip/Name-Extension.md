## Name

Folgende Extensions werden im Kontext des [FHIR Datentyps 'HumanName'](https://www.hl7.org/fhir/datatypes.html#HumanName) definiert:

----

**Name**: Extension-humanname-namenszusatz ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/humanname-namenszusatz&scope=de.basisprofil.r4@1.0.0-alpha1))

**Beschreibung**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/humanname-namenszusatz' select description```

**Canonical**: `http://fhir.de/StructureDefinition/humanname-namenszusatz`

**Kontext**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/humanname-namenszusatz' for context select expression```

{{tree:http://fhir.de/StructureDefinition/humanname-namenszusatz, snapshot}}

**Hinweise**:

Weitere Infos siehe UC_PersoenlicheVersichertendatenXML/Versicherter/Person/Namenszusatz im [Facharchitektur Versichertenstammdaten- management (VSDM)](https://fachportal.gematik.de/fileadmin/user_upload/fachportal/files/Spezifikationen/Basis-Rollout/Fachanwendungen/gematik_VSD_Facharchitektur_VSDM_2_5_0.pdf)

**Beispiel**:

```
<extension url="http://fhir.de/StructureDefinition/humanname-namenszusatz" >
    <valueString value="Gräfin" />
</extension>
```

----