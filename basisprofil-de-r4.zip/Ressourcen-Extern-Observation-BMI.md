----
### BMI

Empfohlen wird die Verwendung des [FHIR Body Mass Index (BMI) Profile](http://hl7.org/implement/standards/fhir/bmi.html) aus der FHIR-Kern-Spezifikation.