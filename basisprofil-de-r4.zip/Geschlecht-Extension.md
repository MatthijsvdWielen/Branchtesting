## Geschlecht

Folgende Extensions werden im Kontext der Abbildung eines [Administrativen Geschlechts](https://wiki.hl7.de/index.php?title=Geschlecht) definiert:

----

**Name**: Extension-address-ags ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/gender-amtlich-de&scope=de.basisprofil.r4@1.0.0-alpha1))

**Beschreibung**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/gender-amtlich-de' select description```

**Canonical**: `http://fhir.de/StructureDefinition/gender-amtlich-de`

**Kontext**: @``` from StructureDefinition where url = 'http://fhir.de/StructureDefinition/gender-amtlich-de' for context select expression```

{{tree:http://fhir.de/StructureDefinition/gender-amtlich-de, snapshot}}

**Hinweise**: n/A

**Beispiel**:

```
<extension url="http://fhir.de/StructureDefinition/gender-amtlich-de" >
    <valueCoding>
        <system value="http://fhir.de/CodeSystem/gender-amtlich-de" />
        <value value="D" />
        <display value="divers" />
    </valueCoding>
</extension>
```