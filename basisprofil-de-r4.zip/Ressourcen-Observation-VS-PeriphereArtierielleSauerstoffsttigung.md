#### Periphere Artierielle Sauerstoffsättigung

**Name**: VitalSignDE_Periphere_Artierielle_Sauerstoffsaettigung ([Simplifier Projekt Link](https://simplifier.net/basisprofil-de-r4/vitalsigndeperiphereartieriellesauerstoffsaettigung))

**Canonical**: `http://fhir.de/StructureDefinition/observation-de-vitalsign-sauerstoffsaettigung`

{{tree:http://fhir.de/StructureDefinition/observation-de-vitalsign-sauerstoffsaettigung, hybrid}}

{{xml:example-pulsoximetrische-sauerstoffsaettigung}}