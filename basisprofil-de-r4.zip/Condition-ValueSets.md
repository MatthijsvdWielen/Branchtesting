----

### Diagnosen (Condition)

**Canonical**: ```http://fhir.de/ValueSet/dimdi/alpha-id```

{{render:http://fhir.de/ValueSet/dimdi/alpha-id}}

<br><br>

**Canonical**: ```http://fhir.de/ValueSet/dimdi/icd-10-gm```

{{render:http://fhir.de/ValueSet/dimdi/icd-10-gm}}