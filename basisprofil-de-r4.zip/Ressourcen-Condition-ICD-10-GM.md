------------

### ICD-10-GM-Kodierung

Nachfolgend wird dokumentiert welche Besonderheiten beachtet werden müssen bei der Erfassung einer Kodierung nach ICD-10 GM. Hintergrundinformationen zu ICD-10 GM werden durch das BfArM herausgegeben. Siehe [Übersicht ICD-10 GM](https://www.dimdi.de/dynamic/de/klassifikationen/icd/icd-10-gm/) oder [Basiswissen Kodieren, 2010 (.pdf)](https://www.dimdi.de/static/.downloads/deutsch/basiswissen-kodieren-2010.pdf).

Ein ICD-10 GM Code kann innerhalb eines Coding-Elementes in FHIR erfasst werden. Hierzu auf folgendes Datentyp-Profil verwiesen: {{pagelink:Datentypen-ICD-10GM-Coding}}.

Das zuvor genannte ICD-10 GM Datentyp-Profil kann in eigenen UseCases zur Erfassung der Diagnose unter Condition.code.coding verwendet werden.

In vielen Fällen kann eine Diganose jedoch zuätzlich in weiteren Kodiersystemen erfasst werden (z.B. [SNOMED-CT](https://www.bfarm.de/EN/Research/SNOMED-CT-NRC/_node.html), [Alpha-ID](https://www.dimdi.de/dynamic/de/klassifikationen/icd/alpha-id/), oder [Orphanet](https://www.orpha.net/consor/cgi-bin/index.php)). Aufgrund dessen wird kein Condition-Profil in den Deutschen Basisprofilen herausgegeben, da die Zusammenstellung der verwendeten Kodiersystemen abhängig vom UseCase ist und somit in eigenständigen FHIR-Profilen erfolgen sollte.

Hinweise zum ValueSet welches für ein entsprechendes Binding des ICD-10 Codings verwendet werden kann, siehe {{pagelink:Terminologie-Codesysteme}}.

<br><br>
#### Postkoordinierte ICD-Codes

ICD-10(-GM) Codes können in postkoordinierter Form auftreten (siehe [Kodierfragen DIMDI](https://www.dimdi.de/dynamic/de/klassifikationen/kodierfrage/Warum-gibt-es-fuer-manche-Diagnosen-mehr-als-eine-Schluesselnummer-z.B.-beim-Kreuz-Stern-System-ICD-10-GMnbspNr.nbsp0010/)).

Postkoordinierte Codes stellen einen validen ICD-10-Code dar und sind daher genau so zu codieren, als handele es sich um einen einzeigen Code.
In manchen Fällen kann es jedoch erforderlich sein, die Codes zu separieren und als Kreuz-/Stern- bzw. Primär-/Sekundär-Code zu qualifizieren.

Dafür stehen Extensions zur Verfügung, die an ein Coding mit postkoordiniertem Code angefügt werden können. Siehe Extension Dokumentation für {{pagelink:ICD10Codierung-Extension}}. Es ist zu beachten, dass die in den Extension verwendeten Codes selbst wiederum gültige ICD-Codes sein.

Die Verwendung der Extensions ist optional. 
Durch die Invarianten icd-1, icd-2, icd-3 und icd-8 wird überprüft, dass die Extensions nur Codes enthalten, die auch Bestandteil der postkoordinierten Form sind.

<br><br>
#### Diagnosesicherheit

Diese Extension "Diagnosesicherheit" kann zur Angabe der Diagnosesicherung in ICD-10-GM-Codierung verwendet werden. Siehe Extension Dokumentation für {{pagelink:ICD10Codierung-Extension}}. 

Die Angabe der äquivalenten Werte für clinicalStatus und verificationStatus ist in diesem Fall dennoch zwingend.
Die Äquivalente gelten wie folgt:

* A (ausgeschlossen) => clinicalStatus = leer, verificationStatus="refuted"
* G (gesicherte Diagnose) => clinicalStatus = "active", verificationStatus="confirmed"
* V (Verdacht auf / zum Ausschluss von) => clinicalStatus = "active", verificationStatus="provisional" oder "differential"
* Z (Zustand nach) => clinicalStatus = "resolved", verificationStatus="confirmed"

Die Äquivalenz von clinicalStatus/verificationStatus und der Diagnosesicherheit wird durch die Invarianten icd-4 bis icd-7 geprüft. 

Mitreden! https://chat.fhir.org/#narrow/stream/179183-german-(d-a-ch)/topic/Invarianten.20f.C3.BCr.20Diagnosesicherheit

<br><br>
#### Beispiel: einfacher ICD-Code

{{xml:Basisprofil-DE-R4/Condition-example-duplicate-5}}

{{json:Basisprofil-DE-R4/Condition-example-duplicate-5}}

#### Beispiel: ICD-Code mit Kreuz-Stern-Notation

{{xml:basisprofil-de-r4/Condition-example-duplicate-4}}

{{json:basisprofil-de-r4/Condition-example-duplicate-4}}

#### Beispiel: ICD-Code mit Ausrufezeichen-Notation

{{xml:Basisprofil-DE-R4/Condition-example}}

{{json:Basisprofil-DE-R4/Condition-example}}

#### Beispiel: Diagnosesicherheit: "Zustand nach"

{{xml:Basisprofil-DE-R4/Condition-example-duplicate-6}}

{{json:Basisprofil-DE-R4/Condition-example-duplicate-6}}