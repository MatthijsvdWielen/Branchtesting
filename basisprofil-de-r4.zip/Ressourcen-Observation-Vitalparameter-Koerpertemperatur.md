#### Körpertemperatur

**Name**: VitalSignDE_Koerpertemperatur ([Simplifier Projekt Link](https://simplifier.net/resolve?canonical=http://fhir.de/StructureDefinition/observation-de-vitalsign-koerpertemperatur&scope=de.basisprofil.r4@1.0.0-alpha1))

**Canonical**: `http://fhir.de/StructureDefinition/observation-de-vitalsign-koerpertemperatur`

{{tree:http://fhir.de/StructureDefinition/observation-de-vitalsign-koerpertemperatur, hybrid}}

{{xml:example-koerpertemperatur}}